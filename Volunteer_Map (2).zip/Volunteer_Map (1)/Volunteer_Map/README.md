## National Map Corps - Volunteer Status Map

This map aims to display the volunteers' contributions to the National Map Corps project. It is intended to be publicly available trough the [NMC's project page](https://my.usgs.gov/confluence/display/nationalmapcorps/Home).
